// pages/dataBase/dataBase.js
const db = wx.cloud.database({
  // env: 'clound1-1gubi6dq60175fb5'
});
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataObj: []
  },
  addData() {
    wx.showLoading({
      title: '数据加载中。。。。',
      mask: true
    })
    db.collection("demoList").add({
      data: {
        title: "1",
        author: "2",
        content: "3"
      }
    }).then(res => {
      console.log(res)
      wx.hideLoading()
    })
  },
  getData() {
    console.log(1)
    db.collection("demoList").where({
      author: "夏琳"
    }).get().then(res => {
      console.log(res)
      this.setData({
        dataObj: res.data
      })
    })
  },
  // getData(){
  //     console.log(1)
  //     db.collection("demoList").doc("058dfefe6299a4d2070550b635059338").get({
  //         success:res=>{
  //             console.log(res.data);
  //             this.setData({
  //                 dataObj:res.data
  //             })
  //         }

  //     })
  // },
  btnSub(res) {
    // var title = res.detail.value.title;
    // var author = res.detail.value.author;
    // var content = res.detail.value.content;
    var {title,author,content} = res.detail.value;
    console.log(title,author,content)
    db.collection("demoList").add({
        data:{
          title:title,
          author:author,
          content:content
        }
    }).then(res=>{
      console.log(res)
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})